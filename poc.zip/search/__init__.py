"""Search utilities for POC."""
