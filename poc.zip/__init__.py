"""POC package for multimodal retrieval demo."""
